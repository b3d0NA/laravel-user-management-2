from flask import Flask, jsonify, render_template, request
from flask_cors import CORS, cross_origin
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

from scraper import (getInitialCategories, getScrapedJson, getSubCategories,
                     getSubSubCategories, initilizeScraper, startScraping)

# creating a Flask app
app = Flask(__name__)
app.config["TEMPLATES_AUTO_RELOAD"] = True
CORS(app, resources={r"/*": {"origins": "*"}})
global driver

options = webdriver.ChromeOptions()
# options.binary_location = os.environ.get("GOOGLE_CHROME_BIN")
options.add_argument("--window-size=1920,1080")
options.add_argument("--start-maximized")
options.add_argument('--headless')
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')
# service = Service(os.environ.get("CHROMEDRIVER_PATH"))
service = Service("/mnt/5470100A49D7EDC7/Projects/Python/chromedriver")
driver = ""


@app.route('/', methods = ['GET'])
def home():
    global driver
    initilizeScraper()
    driver = webdriver.Chrome(service=service, options=options)
    driver.maximize_window()
    results = getInitialCategories(driver)
    categories = [result.text for result in results]
    # categories = ["Men's Fashion"]
    # response = jsonify({"categories": "categories"})
    return render_template("index.html", categories=categories)
  
@app.route('/getSubCats/<index>', methods = ['GET'])
def getSubCats(index):
    sub_cats = getSubCategories(driver, int(index))
    sub_cats = [result.find_element(By.TAG_NAME, "a").text for result in sub_cats]
    response = jsonify({'sub_categories': sub_cats})
    return response

@app.route('/getSubSubCats/<sub_index>/<index>', methods = ['GET'])
def getSubSubCats(sub_index, index):
    sub_sub_cats = getSubSubCategories(driver, int(sub_index), int(index))
    sub_sub_cats = [result.text for result in sub_sub_cats]
    response = jsonify({'sub_sub_categories': sub_sub_cats})
    return response


@app.route('/startScrape', methods = ['POST'])
def startScrape():
    redirect_index = request.json["last_index"]
    page_limit = request.json["page_limit"]
    data_json = startScraping(driver, int(redirect_index), page_limit)
    response = jsonify({'sub_sub_categories': data_json})
    return response

@app.route('/getJson', methods = ['GET'])
def getJson():
    data_json = getScrapedJson(driver)
    response = jsonify({"data": data_json, "current_url": driver.current_url})
    return response
  
if __name__ == '__main__':
    app.run(debug = True)
